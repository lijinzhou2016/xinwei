#!/usr/bin/env python
# -*- coding: UTF-8 -*-

class Dog(object):

    def __init__(self, color, type_, name):
        self._color = color
        self._type_ = type_ 
        self._name = name

    def run(self):
        return "Dog run"

    def get_name(self):
        return self._name 

    def set_color(self, color):
        self._color = color

    def get_color(self):
        return self._color

# print __name__
# 直接执行此文件：输出__main__
# 被其他文件调用输出 dog

if __name__ == "__main__":
    xiaohei = Dog("black", "taidi", "xiaohei")
    print xiaohei.run()
    print xiaohei.get_name()
    print xiaohei.get_color()

    xiaohei.set_color("zongse")
    print xiaohei.get_color()