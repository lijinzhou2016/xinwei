#!/usr/bin/env python
# -*- coding: UTF-8 -*-

import os
import sys
import unittest
import time

BASE_PATH = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
COMMONS_PATH = os.path.join(BASE_PATH, 'commons')
sys.path.append(COMMONS_PATH)
from util import Util


class Common(Util): 
    pass

class Cases(unittest.TestCase):
    def setUp(self):
        self._common = Common()
        self._driver = self._common.get_driver()
        self._logger = self._common.get_logger()
        self._driver.press.home()
        time.sleep(1)

    def tearDown(self):
        pass

    def test_check_setting_menus(self):
        self._driver(resourceId="com.signway.droidkeda:id/btn_set_up").click()
        if self._driver(text="设置").wait.exists(timeout=5000):
            self._logger.debug("enter setting view success")
        else:
            self._logger.error("enter setting view faile")
            self._common.save_image()
            exit(-1)

        # 音量
        self._driver.click(690, 114)
        time.sleep(1)
        level_1 = self._driver(resourceId="com.signway.droidkeda:id/tv_seekbar_voice").text
        self._driver.click(930, 114)
        level_2 = self._driver(resourceId="com.signway.droidkeda:id/tv_seekbar_voice").text
        time.sleep(1)
        if level_1 != level_2:
            self._logger.debug("voice set OK")
        else:
            self._logger.error("voice set error")
            self._common.save_image()

        # 自动休眠


        