cd scripts
python run.py